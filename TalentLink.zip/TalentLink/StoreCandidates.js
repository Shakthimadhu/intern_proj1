const https = require('https');
const fs = require('fs');
const xlsx = require('node-xlsx');

// let query = "{ __type(name: \"ApplicationFilter\") { name fields { name type { name kind } } } }";
// let query = "{ __type(name: \"FullApplicationDto\") { name fields { name type { name kind } } } }";
// let query = "{ __schema { types { name } } }";
// let query = "{ applications(first: 10, after: 0, sortBy: id, orderBy: ASC, where: {id_gt: 0}) { id, documents {id, name, fileUrl {href, method}, type}, attachments ( where { type: \"RESUME\" }) { id, type } } }";


function getData(query, path = '', responseCallback) {

    path = "/tlk/rest/" + path + "?query=" + encodeURI(query);

    let req = https.request(getOptions(path), res => {

        let responseData = '';

        res.on('data', d => {
            responseData += d;
        });


        res.on('end', () => {
            // console.log(responseData);
            responseCallback(JSON.parse(responseData));
        })
    })

    req.on('error', error => {
        console.error(error)
    })

    req.end()
}

function storeDocument(documentID, path = '', fileName = '') {

    let req = https.request(getOptions(`/tlk/rest/candidate/attachment/${documentID}?`), res => {

        let responseData = '';

        res.on('data', d => {
            responseData += d;
        });

        res.on('end', () => {
            responseData = JSON.parse(responseData);

            if ("base64EncodedContent" in responseData) {
                const binaryContent = Buffer.from(responseData['base64EncodedContent'], 'base64');

                let extension = responseData['fileName'].split('.').slice(1).join('.');

                let filePath = path + (fileName != '' ? `${fileName}.${extension}` : (`${documentID}_${responseData['fileName']}`))
                
                if (path  && path != '' && !fs.existsSync(path)) {
                    fs.mkdirSync(path);
                }

                fs.writeFile(filePath, binaryContent, 'binary', (err) => {
                    if (err) {
                        console.error('Error writing file:', err);
                        return;
                    }
                    console.log(`File "${filePath}" created.`);
                });
            }
        })
    })

    req.on('error', error => {
        console.error(error)
    })

    req.end()
}

function getOptions(path) {
    const username = "Mashreq:apiuser:BO";
    const password = "T2#pxhtc";
    const api_key = "984b3edd-d213-a286-ead2-46dbe55ebe2f";
    path += "&api_key=" + api_key;

    // console.log(path)

    return {
        host: 'apiproxy.shared.lumessetalentlink.com',
        path: path,
        headers: { "content-type": "application/json", "username": username, "password": password },
        method: 'get'
    }
}


// Call this to get document attachment IDs
// getData(`{ applications( first: 10 after: 0 sortBy: id orderBy: ASC ) { id attachments { id type } } }`)
// getData("    ")
// getData("{ __schema { types { name fields { name args { name description type { name kind ofType { name kind } } } } } } }")
// getData(`__type(name: "ApplicationFilter") { name description kind fields { name description type { name kind } } } }`)
// getData(`candidate/51840/summary`)


function getCandidates(candidateID = []) {

    let candidateFile = 'storedCandidates.json';
    let storedCandidates = [];

    if(fs.existsSync(candidateFile)) {
        storedCandidates = JSON.parse(fs.readFileSync('storedCandidates.json'));
    }

    candidateID = candidateID.filter(id => !storedCandidates.includes(id))

    if(candidateID.length === 0) {
        return;
    }

    getData(
        `{ candidates(first: 10, after: 0, sortBy: id, orderBy: ASC, where: {id_in: ${JSON.stringify(candidateID)}}) { id, firstname, attachments {id, type}, documents {id, type}, email} }`,
        'candidate',
        (responseData) => {
            responseData.data.candidates.forEach(candidate => {
                let resumes = candidate['attachments'].filter(attachment => attachment.type === 'RESUME');

                let latestResume = resumes.sort((a, b) => b.id - a.id)[0];

                let fileName = `${candidate.id}_${candidate.firstname}`;

                storeDocument(latestResume.id, 'resumes/', fileName)

                storedCandidates.push(candidate.id)

                fs.writeFile(candidateFile, JSON.stringify(storedCandidates), () => null)

                // resumes.forEach(resume => storeDocument(resume.id, null, fileName));
            });
        }
    )
}

const workSheetsFromBuffer = xlsx.parse(fs.readFileSync(`test.xlsx`));

let candidateIDs = [];

for(let i = 1; i < workSheetsFromBuffer[0]['data'].length; i++) {
    let row = workSheetsFromBuffer[0]['data'][i];

    candidateIDs.push(row[0])
}

getCandidates(candidateIDs);

// Call this to store attachement
// storeDocument(1794307);
